module ipn.ejercicio1_4 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ipn.ejercicio1_4 to javafx.fxml;
    exports ipn.ejercicio1_4;
}
