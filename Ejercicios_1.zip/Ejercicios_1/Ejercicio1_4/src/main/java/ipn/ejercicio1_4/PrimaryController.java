package ipn.ejercicio1_4;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML private TextField numero;
    @FXML private TextArea tabla;

    @FXML
    private void switchToSecondary() throws IOException {
        String num = numero.getText();
        int n = Integer.parseInt(num);
        for (int i = 1; i <= 10; i++){
            int mult = n * i;
            tabla.appendText(n + "x" + i + " " + "=" + mult + "\n");
        }
    }
    
    @FXML
    private void cliclk_limpiar() throws IOException {
        numero.clear();
        tabla.clear();
    }
}
