module ipn.ejercicio1_1 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ipn.ejercicio1_1 to javafx.fxml;
    exports ipn.ejercicio1_1;
}
