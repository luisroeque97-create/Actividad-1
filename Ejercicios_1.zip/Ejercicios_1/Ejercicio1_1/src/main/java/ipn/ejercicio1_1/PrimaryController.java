package ipn.ejercicio1_1;

import java.io.IOException;
import javafx.fxml.FXML;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML private TextField fecha;
    @FXML private Label edad;

    @FXML
    private void switchToSecondary() throws IOException {
        String f = fecha.getText(); //10/8/2001
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("d/M/yyyy");
        LocalDate fN = LocalDate.parse(f, formato);
        LocalDate fA = LocalDate.now();
        Period periodo = Period.between(fN, fA);
        int anos = periodo.getYears();
        int meses = periodo.getMonths();
        edad.setText("Tienes " + anos + " años con " + meses + " meses");
    }
    
    @FXML
    private void click_limpiar() throws IOException {
        fecha.clear();
        edad.setText("");
    }
}
