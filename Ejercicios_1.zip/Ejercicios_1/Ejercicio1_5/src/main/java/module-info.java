module ipn.ejercicio1_5 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ipn.ejercicio1_5 to javafx.fxml;
    exports ipn.ejercicio1_5;
}
