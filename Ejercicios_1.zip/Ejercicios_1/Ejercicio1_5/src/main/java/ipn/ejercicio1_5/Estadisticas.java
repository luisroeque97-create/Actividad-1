package ipn.ejercicio1_5;

public class Estadisticas {
    int gastos;

    public Estadisticas(int gastos) {
        this.gastos = gastos;
    }
    
     
    
    
}
