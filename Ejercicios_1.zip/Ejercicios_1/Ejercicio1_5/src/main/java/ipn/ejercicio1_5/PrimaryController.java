package ipn.ejercicio1_5;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class PrimaryController {
    
    @FXML private TextField gastoA;
    @FXML private TextField gastoR;
    @FXML private TextField gastoTr;
    @FXML private TextField gastoTe;
    @FXML private TextField gastoO;
    @FXML private TextField total;
    @FXML private TextField masAlto;

    @FXML
    private void switchToSecondary() throws IOException {
        String Alimen = gastoA.getText();
        int a = Integer.parseInt(Alimen);
        String Refri = gastoR.getText();
        int r = Integer.parseInt(Refri);
        String transp = gastoTr.getText();
        int tr = Integer.parseInt(transp);
        String telefo = gastoTe.getText();
        int te = Integer.parseInt(telefo);
        String otros = gastoO.getText();
        int ot = Integer.parseInt(otros);
        
        Estadisticas[] e = new Estadisticas[]{
            new Estadisticas (a),
            new Estadisticas (r),
            new Estadisticas (tr),
            new Estadisticas (te),
            new Estadisticas (ot),
        };
        
        int mayor = e[0].gastos;
        for (int i = 0; i<e.length; i++){
            if (mayor < e[i].gastos){
                mayor = e[i].gastos;
            }
            if (mayor == e[0].gastos){
                masAlto.setText("Alimentacion");
            }
            if (mayor == e[1].gastos){
                masAlto.setText("Refrigerios");
            }
            if (mayor == e[2].gastos){
                masAlto.setText("Transporte");
            }
            if (mayor == e[3].gastos){
                masAlto.setText("Telefonia");
            }
            if (mayor == e[4].gastos){
                masAlto.setText("Otros");
            }
        }
        
        int sum = 0;
        for (int j = 0; j<e.length; j++){
            sum += e[j].gastos;
        }
        total.setText(String.valueOf(sum));
    }
    
    @FXML
    private void click_limpiar() throws IOException {
        gastoA.clear();
        gastoR.clear();
        gastoTr.clear();
        gastoTe.clear();
        gastoO.clear();
        total.clear();
        masAlto.clear();
    }
}
