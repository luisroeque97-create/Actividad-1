package ipn.ejercicio1_2;

public class Billetes {
    int denominacion;

    public Billetes(int denominacion) {
        this.denominacion = denominacion;
    }

    public int getDenominacion() {
        return denominacion;
    }

    public void setDenominacion(int denominacion) {
        this.denominacion = denominacion;
    }

    @Override
    public String toString() {
        return "Billetes de " + denominacion;
    }
    
    
}
