package ipn.ejercicio1_2;

public class Calcular {
    int dinero;

    public Calcular(int dinero) {
        this.dinero = dinero;
    }
    
    public String desgloze(){
        int [] denominaciones = {500, 200, 100, 50, 20, 10, 5, 2, 1};
        StringBuilder resultado = new StringBuilder();
        int resta = dinero;
        
        for (int o : denominaciones){
            if (resta >= 0){
                int cantidad = resta / o;
                resta = resta % o;
                resultado.append(cantidad).append("\n");
            }
        }
        return resultado.toString();  
    }
}
