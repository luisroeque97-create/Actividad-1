package ipn.ejercicio1_2;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController implements Initializable {
    @FXML private TextArea billetes;
    @FXML private TextArea desgloze;
    @FXML private TextField dineroEs;
    @FXML private Button limpiar;
    @FXML private Button primaryButton;

    @FXML
    private void switchToSecondary() throws IOException {
        String dineroC = dineroEs.getText();
        int dineroT = Integer.parseInt(dineroC);
        
        Calcular calc = new Calcular(dineroT);
        String resultado = calc.desgloze();
        desgloze.setText(resultado);
        
        }
    
    @FXML
    private void click_limpiar() throws IOException {
        dineroEs.clear();
        desgloze.clear();
        }

        @Override
        public void initialize(URL url, ResourceBundle rb) {
            Billetes[] b = new Billetes[]{
			new Billetes(500),
			new Billetes(200),
                        new Billetes(100),
                        new Billetes(50),
                        new Billetes(20),
                        new Billetes(10),
                        new Billetes(5),
                        new Billetes(2),
                        new Billetes(1),
            };
            for (int i=0; i<9; i++) {
                billetes.appendText(b[i].toString() + "\n");
            }
        }
}
