package ipn.ejercicio1_2;

public class Desglozar {
    
}
