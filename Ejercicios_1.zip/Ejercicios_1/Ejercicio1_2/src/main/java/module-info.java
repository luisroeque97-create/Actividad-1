module ipn.ejercicio1_2 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ipn.ejercicio1_2 to javafx.fxml;
    exports ipn.ejercicio1_2;
}
