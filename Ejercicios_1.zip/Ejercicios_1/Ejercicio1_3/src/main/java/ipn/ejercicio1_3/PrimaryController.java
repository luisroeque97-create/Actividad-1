package ipn.ejercicio1_3;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PrimaryController {
    @FXML private TextField num;
    @FXML private TextField canCif;
    @FXML private TextField sumImp;
    @FXML private TextField sumPar;
    @FXML private TextField sumCif;
    @FXML private TextField cifMay;
    @FXML private TextField cifMen;
    @FXML private TextArea div;

    @FXML
    private void switchToSecondary() throws IOException {
        int imp = 0;
        int par = 0;
        int total = 0;
        int mayor = -1;
        int menor = 11;
        
        String cifra = num.getText();
        int c = Integer.parseInt(cifra);
        
        int caCi = String.valueOf(Math.abs(c)).length();
        canCif.setText(String.valueOf(caCi));
        
        String txt = String.valueOf(c);
        for (int i = 0; i < txt.length(); i++){
            int n = Character.getNumericValue(txt.charAt(i));
            total += n;
            if (mayor < n){
                mayor = n;
            }
            if (menor > n){
                menor = n;
            }
            if (n %2 == 0){
                par += n;
            }
            if (n %2 != 0){
                imp += n;
            }
        }
        sumImp.setText(String.valueOf(imp));
        sumPar.setText(String.valueOf(par));
        sumCif.setText(String.valueOf(total));
        cifMay.setText(String.valueOf(mayor));
        cifMen.setText(String.valueOf(menor));
        
        String divisores = "";
        for (int j = 1; j< c; j++){
            if (c%j == 0 ){
                divisores += j + "\n";
            }
        }
        div.setText(divisores + cifra);
        
    }
    
    @FXML
    private void cliclk_limpiar() throws IOException {
    num.clear();
    canCif.clear();
    sumImp.clear();
    sumPar.clear();
    sumCif.clear();
    cifMay.clear();
    cifMen.clear();
    div.clear();
    }
}
