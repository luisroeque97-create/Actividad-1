module ipn.ejercicio1_3 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ipn.ejercicio1_3 to javafx.fxml;
    exports ipn.ejercicio1_3;
}
